package textTrunRPG;

import java.util.ArrayList;

public class Player extends GameCharacter {
	int gold;
	ArrayList inventory;
	
	public Player(String name) {
		super(name,  100,  15);
		this.gold = 100;
		this.inventory = new ArrayList();
		this.inventory.add("빨간포션");
	}
}
