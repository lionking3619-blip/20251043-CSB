package textTrunRPG;

import java.io.*;
import java.util.Scanner;
import java.util.InputMismatchException;

public class Main {
	static Player player;
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("=== 턴제 RPG ===");
		System.out.println("닉네임을 입력하세요: ");
		String name = scanner.nextLine();
		
		player = new Player(name);
		
		loadGame();
		
		while(true) {
			System.out.println("\n[마을] 무엇을 하시곘습니까?");
			System.out.println("1. 사냥터");
			System.out.println("2. 스테이터스/인벤토리");
			System.out.println("3. 게임 저장 및 종료");
			System.out.println("메뉴 번호 선택: ");
			
			int menu = 0;
			try {
				menu = scanner.nextInt();
				scanner.nextLine();
			} catch(InputMismatchException e) {
				System.out.println("숫자만 입력해주세요.");
				scanner.nextLine();
				continue;
			}
			
			switch(menu) {
				case 1:
					startBattle();
					break;
				case 2:
					showInventory();
					break;
				case 3:
					saveGame();
					System.out.println("게임이 저장되었습니다. 게임을 종료합니다.");
					return;
				default:
					System.out.println("잘못된 번호입니다. 옳은 번호를 입력해주세요.");
			}
		}
	}
	
	public static void startBattle() {
		String monsterName = (Math.random() > 0.5) ? "슬라임" : "고블린";
		GameCharacter monster = new GameCharacter(monsterName, 40, 8);
		
		System.out.println("\n앗! 야생의 [" + monster.name + "](이)가 나타났다!");
		
		while(player.hp > 0 && monster.hp > 0) {
			System.out.println("\n[현재 상황] 내 HP: " + player.hp + " | " + monster.name + " HP: " + monster.hp);
			System.out.println("1. 공격한다 | 2. 도망친다");
			System.out.print("선택: ");
			
			int action;
			try {
				action = scanner.nextInt();
				scanner.nextLine();
			} catch(InputMismatchException e) {
				System.out.println("숫자만 입력해주세요.");
				scanner.nextLine();
				continue;
			}
			
			if(action == 1) {
				player.attack(monster);
				
				if(monster.hp <= 0) {
					System.out.println("\n축하합니다!" + monster.name + "을(를) 처치했습니다!");
					
					int rewardGold = (int)(Math.random() * 21) + 10;
					player.gold += rewardGold;
					System.out.println(rewardGold + "골드를 얻었습니다.(보유 골드: " + player.gold + ")");
					
					if(Math.random() < 0.3) {
						player.inventory.add("빨간포션");
						System.out.println("[아이템 획득] 몬스터가 '빨간포션'을 떨어뜨렸습니다.");
					}
					break;
				}
				
				monster.attack(player);
				
				if(player.hp <= 0) {
					System.out.println("\n무력화되었습니다.");
					System.out.println("마을로 텔레포트합니다.");
					player.hp = player.maxHp;
					break;
				}
			} else {
				System.out.println("무사히 도망쳤습니다.");
				break;
			}
			
		}
	}
	
	public static void showInventory() {
		System.out.println("\n==== " + player.name + "의 정보 ====");
		System.out.println("체력: " + player.hp + "/" + player.maxHp);
		System.out.println("보유 골드: " + player.gold + "G");
		System.out.println("------------------------------");
		System.out.println("[인벤토리 목록]");
		
		if(player.inventory.isEmpty()) {
			System.out.println("(비어 있음)");
		} else {
			for(int i = 0; i < player.inventory.size(); i++) {
				System.out.println("[" + i + "]" + player.inventory.get(i));
			}
			
			System.out.print("사용할 아이템 번호를 입력하세요(취소는 -1): ");
			int itemNum = -1;
			try {
				itemNum = scanner.nextInt();
				scanner.nextLine();
			} catch(InputMismatchException e) {
				System.out.println("숫자만 입력해주세요.");
				scanner.nextLine();
			}
			
			if(itemNum >= 0 && itemNum < player.inventory.size()) {
				String usedItem = (String)player.inventory.remove(itemNum);
				
				if(usedItem.equals("빨간포션")) {
					player.hp += 40;
					if(player.hp > player.maxHp) player.hp = player.maxHp;
					System.out.println("빨간포션을 사용했습니다. 체력이 40 회복되었습니다.");
				}
			} else {
				System.out.println("아이템 사용을 취소했습니다.");
			}
		}
	}
	
	public static void saveGame() {
		try(BufferedWriter bw = new BufferedWriter(new FileWriter("savefile.txt"))) {
			bw.write(player.name + "\n");
			bw.write(player.hp + "\n");
			bw.write(player.gold + "\n");
			
			for(int i = 0; i < player.inventory.size(); i++) {
				bw.write(player.inventory.get(i) + ",");
			}
			bw.write("\n");
		} catch(IOException e) {
			System.out.println("게임 저장 중 에러가 발생했습니다: " + e.getMessage());
		}
	}
	
	public static void loadGame() {
		File file = new File("savefile.txt");
		if(!file.exists()) return;
		
		try(BufferedReader br = new BufferedReader(new FileReader(file))) {
			String savedName = br.readLine();
			int savedHp = Integer.parseInt(br.readLine());
			int savedGold = Integer.parseInt(br.readLine());
			String savedItems = br.readLine();
			
			if(savedName != null) {
				player.name = savedName;
				player.hp = savedHp;
				player.gold = savedGold;
				
				player.inventory.clear();
				if(savedItems != null && !savedItems.trim().isEmpty()) {
					String[] itemsArray = savedItems.split(",");
					for(String item : itemsArray) {
						if(!item.trim().isEmpty()) {
							player.inventory.add(item);
						}
					}
				}
				System.out.println("\n[시스템] 이전 저장 데이터를 성공적으로 불러왔습니다.");
			}
		} catch(Exception e) {
			System.out.println("[시스템] 저장 파일을 읽는 중 오류가 발생해 새 게임으로 시작합니다.");
		}
	}
}
